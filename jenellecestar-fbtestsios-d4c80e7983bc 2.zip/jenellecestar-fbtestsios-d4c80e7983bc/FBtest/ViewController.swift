//
//  ViewController.swift
//  FBtest
//
//  Created by robin on 2018-07-19.
//  Copyright © 2018 robin. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase


class ViewController: UIViewController {

    var db : DatabaseReference!
    @IBOutlet weak var textview: UITextField!
    
    @IBAction func addTaskPressed(_ sender: UIButton) {
        print("Add task pressed")
        
        let x = textview.text!
        
        if(x.isEmpty == true) {
            return
        }
        
        self.db.child("todos").childByAutoId().setValue(x)
        
            textview.text = ""
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //setup your FB variable
        self.db = Database.database().reference()
        
        //add something to the database
        /*self.db.setValue(123)
        
        let x: [String: Any] = ["age":22,"color":"white"]
        self.db.setValue(x)
        
        self.db.child("cars").setValue(55)
        self.db.child("name").setValue("Rohan")
        
        self.db.childByAutoId().setValue("Hello World")
        self.db.childByAutoId().setValue("apple")
        self.db.childByAutoId().setValue("banana")
        self.db.childByAutoId().setValue("carrot")
        self.db.childByAutoId().setValue("donut")*/
        watchForChanges()
        
    }
    
    func watchForChanges() {
        self.db.child("todos").observe(DataEventType.childAdded, with: {
            (snapshot) in
            
            print("----something was added!!!--")
            
            let x = snapshot.value!
            print(x)
            print("----------------------------")
        })
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

